@include('layout._includes.siteinterno.topo')

@yield('conteudo')

@include('layout._includes.siteinterno.footer')
