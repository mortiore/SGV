@extends ('layout.ecommerce')

@section('titulo','Index e-commerce')

@section('conteudo')



@endsection
