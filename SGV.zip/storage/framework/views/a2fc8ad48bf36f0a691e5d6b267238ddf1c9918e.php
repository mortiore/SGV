<?php echo $__env->make('layout._includes.ecommerce.toposite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('conteudo'); ?>

<?php echo $__env->make('layout._includes.ecommerce.footersite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\Users\Fábio\code\SGV\resources\views/layout/ecommerce.blade.php ENDPATH**/ ?>