<?php echo $__env->make('layout._includes.siteinterno.topo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('conteudo'); ?>

<?php echo $__env->make('layout._includes.siteinterno.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Fábio\code\SGV\resources\views/layout/siteinterno.blade.php ENDPATH**/ ?>