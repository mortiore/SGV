<?php $__env->startSection('titulo','Login e-commerce'); ?>

<?php $__env->startSection('conteudo'); ?>

    <main>
        <div class="container">
            <div class="row justify-content-center">
                <form action="<?php echo e(route('entrar.cliente')); ?>" method="put" class="col-sm-10 col-md-8 col-lg-6">
                <h1 class="mb-3">Faça login na sua conta</h1>

                <?php echo e(csrf_field()); ?>


                <div class="input-field">
                    <label style="color: #c29a5c;">Login</label>
                    <input type="text" name="email" required>
                </div>

                <div class="input-field">
                    <label style="color: #c29a5c;">Senha</label>
                    <input type="password" name="password" required>
                </div>

                    <div class="form-check mb-3">
                    <label>
                    <input type="checkbox" />
                    <span>Lembrar-se</span>
                    </label>
                    </div>

                    <button style="height: 60px; color: #c29a5c;" class="btn btn-secondary">Entrar <br><i class="material-icons">login</i></button>
                    <p class="mt-3">
                        Ainda não é cadastrado? <a href="<?php echo e(route('ecommerce.cadastro')); ?>">Clique aqui</a> para se cadastrar.
                    </p>
                    <p class="mt-3">
                        Esqueceu sua senha? <a href="/src/recuperarsenha.html">Clique aqui</a> para recuperá-la.
                    </p>

                </form>
            </div>
        </div>
    </main>

    <div style="height: 273px;" class="d-block d-md-none"></div>
    <div style="height: 153px;" class="d-none d-md-block d-lg-none"></div>
    <div style="height: 129px;" class="d-none d-lg-block"></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.ecommerce', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fábio\code\SGV\resources\views/ecommerce/login.blade.php ENDPATH**/ ?>