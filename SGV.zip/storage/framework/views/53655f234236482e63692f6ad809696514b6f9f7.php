
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\Users\Fábio\code\SGV\resources\views/layout/_includes/siteinterno/footer.blade.php ENDPATH**/ ?>