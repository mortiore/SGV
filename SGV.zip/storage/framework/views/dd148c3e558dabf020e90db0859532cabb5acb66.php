<?php $__env->startSection('titulo','Área de Login'); ?>

<?php $__env->startSection('conteudo'); ?>
<div style="max-width: unset !important; background-color: #314153 ; padding-bottom: 20px;" class="container">

    <div style="padding-bottom: 30px; width: 400px; padding-top: 30px;" class="container">

    <div style="box-shadow: 8px 5px 5px rgba(0, 0, 0, .3);" class="center">
        <img  style="width: 370px; height: 225px; object-fit: cover; object-position: 0px -50px;" src="<?php echo e(asset('/img/Selaria.png')); ?>"/>
        <!--  -->
    </div>

    </div>

</div>

<div style="padding-bottom: 20px;" class="center">

<div style="width: 400px;" class="container">
        <h1 style="padding-top: 20px;padding-bottom: 20px; color: #c29a5c;" class="center">Portal Interno</h1>

        <div style="max-width: unset !important; background-color: #314153 ; padding-bottom: 20px; border-radius: 2.5%;" class="container">

            <div class="container" style="padding-top: 40px;">

                <form action="<?php echo e(route('entrar')); ?>" method="put">

                <?php echo e(csrf_field()); ?>


                <div class="input-field">
                    <label style="color: #c29a5c;">Login</label>
                    <input type="text" name="email" required>
                </div>

                <div class="input-field">
                    <label style="color: #c29a5c;">Senha</label>
                    <input type="password" name="password" required>
                </div>

                <div style="padding-top: 30px; padding-bottom: 20px;" class="center">

                <button style="height: 60px; color: #c29a5c;" class="btn btn-secondary">Entrar <br><i class="material-icons">login</i></button>

                </div>

                </form>

            </div>
        </div>
</div>


</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.siteinterno', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fábio\code\SGV\resources\views/index.blade.php ENDPATH**/ ?>